`define PORT_BUS_IDLE        3'b000
`define PORT_READ_CYCLE		 3'b001
`define PORT_WRITE_CYCLE     3'b100
`define PORT_DATA_OUT		 3'b010
`define PORT_BUS_CLEAR       3'b011
`define PORT_WRITE_ASSERT    3'b101
`define PORT_WRITE_DEASSERT  3'b110
`define PORT_WRITE_CLEAR     3'b111

