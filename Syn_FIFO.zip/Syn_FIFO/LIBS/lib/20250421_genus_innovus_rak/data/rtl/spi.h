`define SPI_IDLE		3'b001
`define SPI_BYTE_START	3'b000
`define SPI_BYTE		3'b010
`define SPI_TRANS_BYTE	3'b011
`define SPI_TRANSFER	3'b111
